package trik.testsys.grading;

import static io.grpc.MethodDescriptor.generateFullMethodName;

/**
 */
@javax.annotation.Generated(
    value = "by gRPC proto compiler (version 1.66.0)",
    comments = "Source: grading_node.proto")
@io.grpc.stub.annotations.GrpcGenerated
public final class GradingNodeGrpc {

  private GradingNodeGrpc() {}

  public static final java.lang.String SERVICE_NAME = "trik.testsys.grading.GradingNode";

  // Static method descriptors that strictly reflect the proto.
  private static volatile io.grpc.MethodDescriptor<trik.testsys.grading.GradingNodeOuterClass.Submission,
      trik.testsys.grading.GradingNodeOuterClass.Result> getGradeMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "Grade",
      requestType = trik.testsys.grading.GradingNodeOuterClass.Submission.class,
      responseType = trik.testsys.grading.GradingNodeOuterClass.Result.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<trik.testsys.grading.GradingNodeOuterClass.Submission,
      trik.testsys.grading.GradingNodeOuterClass.Result> getGradeMethod() {
    io.grpc.MethodDescriptor<trik.testsys.grading.GradingNodeOuterClass.Submission, trik.testsys.grading.GradingNodeOuterClass.Result> getGradeMethod;
    if ((getGradeMethod = GradingNodeGrpc.getGradeMethod) == null) {
      synchronized (GradingNodeGrpc.class) {
        if ((getGradeMethod = GradingNodeGrpc.getGradeMethod) == null) {
          GradingNodeGrpc.getGradeMethod = getGradeMethod =
              io.grpc.MethodDescriptor.<trik.testsys.grading.GradingNodeOuterClass.Submission, trik.testsys.grading.GradingNodeOuterClass.Result>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "Grade"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  trik.testsys.grading.GradingNodeOuterClass.Submission.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  trik.testsys.grading.GradingNodeOuterClass.Result.getDefaultInstance()))
              .setSchemaDescriptor(new GradingNodeMethodDescriptorSupplier("Grade"))
              .build();
        }
      }
    }
    return getGradeMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.google.protobuf.Empty,
      trik.testsys.grading.GradingNodeOuterClass.Status> getGetStatusMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetStatus",
      requestType = com.google.protobuf.Empty.class,
      responseType = trik.testsys.grading.GradingNodeOuterClass.Status.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.google.protobuf.Empty,
      trik.testsys.grading.GradingNodeOuterClass.Status> getGetStatusMethod() {
    io.grpc.MethodDescriptor<com.google.protobuf.Empty, trik.testsys.grading.GradingNodeOuterClass.Status> getGetStatusMethod;
    if ((getGetStatusMethod = GradingNodeGrpc.getGetStatusMethod) == null) {
      synchronized (GradingNodeGrpc.class) {
        if ((getGetStatusMethod = GradingNodeGrpc.getGetStatusMethod) == null) {
          GradingNodeGrpc.getGetStatusMethod = getGetStatusMethod =
              io.grpc.MethodDescriptor.<com.google.protobuf.Empty, trik.testsys.grading.GradingNodeOuterClass.Status>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "GetStatus"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.protobuf.Empty.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  trik.testsys.grading.GradingNodeOuterClass.Status.getDefaultInstance()))
              .setSchemaDescriptor(new GradingNodeMethodDescriptorSupplier("GetStatus"))
              .build();
        }
      }
    }
    return getGetStatusMethod;
  }

  /**
   * Creates a new async stub that supports all call types for the service
   */
  public static GradingNodeStub newStub(io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<GradingNodeStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<GradingNodeStub>() {
        @java.lang.Override
        public GradingNodeStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new GradingNodeStub(channel, callOptions);
        }
      };
    return GradingNodeStub.newStub(factory, channel);
  }

  /**
   * Creates a new blocking-style stub that supports unary and streaming output calls on the service
   */
  public static GradingNodeBlockingStub newBlockingStub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<GradingNodeBlockingStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<GradingNodeBlockingStub>() {
        @java.lang.Override
        public GradingNodeBlockingStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new GradingNodeBlockingStub(channel, callOptions);
        }
      };
    return GradingNodeBlockingStub.newStub(factory, channel);
  }

  /**
   * Creates a new ListenableFuture-style stub that supports unary calls on the service
   */
  public static GradingNodeFutureStub newFutureStub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<GradingNodeFutureStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<GradingNodeFutureStub>() {
        @java.lang.Override
        public GradingNodeFutureStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new GradingNodeFutureStub(channel, callOptions);
        }
      };
    return GradingNodeFutureStub.newStub(factory, channel);
  }

  /**
   */
  public interface AsyncService {

    /**
     */
    default void grade(trik.testsys.grading.GradingNodeOuterClass.Submission request,
        io.grpc.stub.StreamObserver<trik.testsys.grading.GradingNodeOuterClass.Result> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getGradeMethod(), responseObserver);
    }

    /**
     */
    default void getStatus(com.google.protobuf.Empty request,
        io.grpc.stub.StreamObserver<trik.testsys.grading.GradingNodeOuterClass.Status> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getGetStatusMethod(), responseObserver);
    }
  }

  /**
   * Base class for the server implementation of the service GradingNode.
   */
  public static abstract class GradingNodeImplBase
      implements io.grpc.BindableService, AsyncService {

    @java.lang.Override public final io.grpc.ServerServiceDefinition bindService() {
      return GradingNodeGrpc.bindService(this);
    }
  }

  /**
   * A stub to allow clients to do asynchronous rpc calls to service GradingNode.
   */
  public static final class GradingNodeStub
      extends io.grpc.stub.AbstractAsyncStub<GradingNodeStub> {
    private GradingNodeStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected GradingNodeStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new GradingNodeStub(channel, callOptions);
    }

    /**
     */
    public void grade(trik.testsys.grading.GradingNodeOuterClass.Submission request,
        io.grpc.stub.StreamObserver<trik.testsys.grading.GradingNodeOuterClass.Result> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getGradeMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void getStatus(com.google.protobuf.Empty request,
        io.grpc.stub.StreamObserver<trik.testsys.grading.GradingNodeOuterClass.Status> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getGetStatusMethod(), getCallOptions()), request, responseObserver);
    }
  }

  /**
   * A stub to allow clients to do synchronous rpc calls to service GradingNode.
   */
  public static final class GradingNodeBlockingStub
      extends io.grpc.stub.AbstractBlockingStub<GradingNodeBlockingStub> {
    private GradingNodeBlockingStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected GradingNodeBlockingStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new GradingNodeBlockingStub(channel, callOptions);
    }

    /**
     */
    public trik.testsys.grading.GradingNodeOuterClass.Result grade(trik.testsys.grading.GradingNodeOuterClass.Submission request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getGradeMethod(), getCallOptions(), request);
    }

    /**
     */
    public trik.testsys.grading.GradingNodeOuterClass.Status getStatus(com.google.protobuf.Empty request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getGetStatusMethod(), getCallOptions(), request);
    }
  }

  /**
   * A stub to allow clients to do ListenableFuture-style rpc calls to service GradingNode.
   */
  public static final class GradingNodeFutureStub
      extends io.grpc.stub.AbstractFutureStub<GradingNodeFutureStub> {
    private GradingNodeFutureStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected GradingNodeFutureStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new GradingNodeFutureStub(channel, callOptions);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<trik.testsys.grading.GradingNodeOuterClass.Result> grade(
        trik.testsys.grading.GradingNodeOuterClass.Submission request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getGradeMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<trik.testsys.grading.GradingNodeOuterClass.Status> getStatus(
        com.google.protobuf.Empty request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getGetStatusMethod(), getCallOptions()), request);
    }
  }

  private static final int METHODID_GRADE = 0;
  private static final int METHODID_GET_STATUS = 1;

  private static final class MethodHandlers<Req, Resp> implements
      io.grpc.stub.ServerCalls.UnaryMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ServerStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ClientStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.BidiStreamingMethod<Req, Resp> {
    private final AsyncService serviceImpl;
    private final int methodId;

    MethodHandlers(AsyncService serviceImpl, int methodId) {
      this.serviceImpl = serviceImpl;
      this.methodId = methodId;
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public void invoke(Req request, io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        case METHODID_GRADE:
          serviceImpl.grade((trik.testsys.grading.GradingNodeOuterClass.Submission) request,
              (io.grpc.stub.StreamObserver<trik.testsys.grading.GradingNodeOuterClass.Result>) responseObserver);
          break;
        case METHODID_GET_STATUS:
          serviceImpl.getStatus((com.google.protobuf.Empty) request,
              (io.grpc.stub.StreamObserver<trik.testsys.grading.GradingNodeOuterClass.Status>) responseObserver);
          break;
        default:
          throw new AssertionError();
      }
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public io.grpc.stub.StreamObserver<Req> invoke(
        io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        default:
          throw new AssertionError();
      }
    }
  }

  public static final io.grpc.ServerServiceDefinition bindService(AsyncService service) {
    return io.grpc.ServerServiceDefinition.builder(getServiceDescriptor())
        .addMethod(
          getGradeMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              trik.testsys.grading.GradingNodeOuterClass.Submission,
              trik.testsys.grading.GradingNodeOuterClass.Result>(
                service, METHODID_GRADE)))
        .addMethod(
          getGetStatusMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.google.protobuf.Empty,
              trik.testsys.grading.GradingNodeOuterClass.Status>(
                service, METHODID_GET_STATUS)))
        .build();
  }

  private static abstract class GradingNodeBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoFileDescriptorSupplier, io.grpc.protobuf.ProtoServiceDescriptorSupplier {
    GradingNodeBaseDescriptorSupplier() {}

    @java.lang.Override
    public com.google.protobuf.Descriptors.FileDescriptor getFileDescriptor() {
      return trik.testsys.grading.GradingNodeOuterClass.getDescriptor();
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.ServiceDescriptor getServiceDescriptor() {
      return getFileDescriptor().findServiceByName("GradingNode");
    }
  }

  private static final class GradingNodeFileDescriptorSupplier
      extends GradingNodeBaseDescriptorSupplier {
    GradingNodeFileDescriptorSupplier() {}
  }

  private static final class GradingNodeMethodDescriptorSupplier
      extends GradingNodeBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoMethodDescriptorSupplier {
    private final java.lang.String methodName;

    GradingNodeMethodDescriptorSupplier(java.lang.String methodName) {
      this.methodName = methodName;
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.MethodDescriptor getMethodDescriptor() {
      return getServiceDescriptor().findMethodByName(methodName);
    }
  }

  private static volatile io.grpc.ServiceDescriptor serviceDescriptor;

  public static io.grpc.ServiceDescriptor getServiceDescriptor() {
    io.grpc.ServiceDescriptor result = serviceDescriptor;
    if (result == null) {
      synchronized (GradingNodeGrpc.class) {
        result = serviceDescriptor;
        if (result == null) {
          serviceDescriptor = result = io.grpc.ServiceDescriptor.newBuilder(SERVICE_NAME)
              .setSchemaDescriptor(new GradingNodeFileDescriptorSupplier())
              .addMethod(getGradeMethod())
              .addMethod(getGetStatusMethod())
              .build();
        }
      }
    }
    return result;
  }
}
