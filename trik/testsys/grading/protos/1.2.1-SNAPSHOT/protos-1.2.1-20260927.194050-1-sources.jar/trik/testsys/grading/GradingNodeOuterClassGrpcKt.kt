package trik.testsys.grading

import com.google.protobuf.Empty
import io.grpc.CallOptions
import io.grpc.CallOptions.DEFAULT
import io.grpc.Channel
import io.grpc.Metadata
import io.grpc.MethodDescriptor
import io.grpc.ServerServiceDefinition
import io.grpc.ServerServiceDefinition.builder
import io.grpc.ServiceDescriptor
import io.grpc.Status.UNIMPLEMENTED
import io.grpc.StatusException
import io.grpc.kotlin.AbstractCoroutineServerImpl
import io.grpc.kotlin.AbstractCoroutineStub
import io.grpc.kotlin.ClientCalls.unaryRpc
import io.grpc.kotlin.ServerCalls.unaryServerMethodDefinition
import io.grpc.kotlin.StubFor
import kotlin.String
import kotlin.coroutines.CoroutineContext
import kotlin.coroutines.EmptyCoroutineContext
import kotlin.jvm.JvmOverloads
import kotlin.jvm.JvmStatic
import trik.testsys.grading.GradingNodeGrpc.getServiceDescriptor

/**
 * Holder for Kotlin coroutine-based client and server APIs for trik.testsys.grading.GradingNode.
 */
public object GradingNodeGrpcKt {
  public const val SERVICE_NAME: String = GradingNodeGrpc.SERVICE_NAME

  @JvmStatic
  public val serviceDescriptor: ServiceDescriptor
    get() = getServiceDescriptor()

  public val gradeMethod:
      MethodDescriptor<GradingNodeOuterClass.Submission, GradingNodeOuterClass.Result>
    @JvmStatic
    get() = GradingNodeGrpc.getGradeMethod()

  public val getStatusMethod: MethodDescriptor<Empty, GradingNodeOuterClass.Status>
    @JvmStatic
    get() = GradingNodeGrpc.getGetStatusMethod()

  /**
   * A stub for issuing RPCs to a(n) trik.testsys.grading.GradingNode service as suspending
   * coroutines.
   */
  @StubFor(GradingNodeGrpc::class)
  public class GradingNodeCoroutineStub @JvmOverloads constructor(
    channel: Channel,
    callOptions: CallOptions = DEFAULT,
  ) : AbstractCoroutineStub<GradingNodeCoroutineStub>(channel, callOptions) {
    override fun build(channel: Channel, callOptions: CallOptions): GradingNodeCoroutineStub =
        GradingNodeCoroutineStub(channel, callOptions)

    /**
     * Executes this RPC and returns the response message, suspending until the RPC completes
     * with [`Status.OK`][io.grpc.Status].  If the RPC completes with another status, a
     * corresponding
     * [StatusException] is thrown.  If this coroutine is cancelled, the RPC is also cancelled
     * with the corresponding exception as a cause.
     *
     * @param request The request message to send to the server.
     *
     * @param headers Metadata to attach to the request.  Most users will not need this.
     *
     * @return The single response from the server.
     */
    public suspend fun grade(request: GradingNodeOuterClass.Submission, headers: Metadata =
        Metadata()): GradingNodeOuterClass.Result = unaryRpc(
      channel,
      GradingNodeGrpc.getGradeMethod(),
      request,
      callOptions,
      headers
    )

    /**
     * Executes this RPC and returns the response message, suspending until the RPC completes
     * with [`Status.OK`][io.grpc.Status].  If the RPC completes with another status, a
     * corresponding
     * [StatusException] is thrown.  If this coroutine is cancelled, the RPC is also cancelled
     * with the corresponding exception as a cause.
     *
     * @param request The request message to send to the server.
     *
     * @param headers Metadata to attach to the request.  Most users will not need this.
     *
     * @return The single response from the server.
     */
    public suspend fun getStatus(request: Empty, headers: Metadata = Metadata()):
        GradingNodeOuterClass.Status = unaryRpc(
      channel,
      GradingNodeGrpc.getGetStatusMethod(),
      request,
      callOptions,
      headers
    )
  }

  /**
   * Skeletal implementation of the trik.testsys.grading.GradingNode service based on Kotlin
   * coroutines.
   */
  public abstract class GradingNodeCoroutineImplBase(
    coroutineContext: CoroutineContext = EmptyCoroutineContext,
  ) : AbstractCoroutineServerImpl(coroutineContext) {
    /**
     * Returns the response to an RPC for trik.testsys.grading.GradingNode.Grade.
     *
     * If this method fails with a [StatusException], the RPC will fail with the corresponding
     * [io.grpc.Status].  If this method fails with a [java.util.concurrent.CancellationException],
     * the RPC will fail
     * with status `Status.CANCELLED`.  If this method fails for any other reason, the RPC will
     * fail with `Status.UNKNOWN` with the exception as a cause.
     *
     * @param request The request from the client.
     */
    public open suspend fun grade(request: GradingNodeOuterClass.Submission):
        GradingNodeOuterClass.Result = throw
        StatusException(UNIMPLEMENTED.withDescription("Method trik.testsys.grading.GradingNode.Grade is unimplemented"))

    /**
     * Returns the response to an RPC for trik.testsys.grading.GradingNode.GetStatus.
     *
     * If this method fails with a [StatusException], the RPC will fail with the corresponding
     * [io.grpc.Status].  If this method fails with a [java.util.concurrent.CancellationException],
     * the RPC will fail
     * with status `Status.CANCELLED`.  If this method fails for any other reason, the RPC will
     * fail with `Status.UNKNOWN` with the exception as a cause.
     *
     * @param request The request from the client.
     */
    public open suspend fun getStatus(request: Empty): GradingNodeOuterClass.Status = throw
        StatusException(UNIMPLEMENTED.withDescription("Method trik.testsys.grading.GradingNode.GetStatus is unimplemented"))

    final override fun bindService(): ServerServiceDefinition = builder(getServiceDescriptor())
      .addMethod(unaryServerMethodDefinition(
      context = this.context,
      descriptor = GradingNodeGrpc.getGradeMethod(),
      implementation = ::grade
    ))
      .addMethod(unaryServerMethodDefinition(
      context = this.context,
      descriptor = GradingNodeGrpc.getGetStatusMethod(),
      implementation = ::getStatus
    )).build()
  }
}
